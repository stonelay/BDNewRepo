//
//  NewRepoModel.h
//  BDNewRepo
//
//  Created by Lay on 2020/5/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NewRepoModel : NSObject

- (NSString *)modelName;

@end

NS_ASSUME_NONNULL_END
