//
//  BDHelpfulUtilGlobal.h
//  BDHelpfulUtil
//
//  Created by Lay on 2020/4/8.
//

#ifndef BDNewRepoGlobal_h
#define BDNewRepoGlobal_h

#define STRING(str)  ((str) != nil ? [NSString stringWithFormat:@"%@", (str)] : @"")

#endif /* BDAttributeMakerGlobal_h */
